﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicPlayer : MonoBehaviour
{
    private static MusicPlayer SingleMusicPlayer = null;
    
    private void Start()
    {
        if (SingleMusicPlayer != null)
        {
            Destroy(gameObject);
        }
        else
        {
            SingleMusicPlayer = this;
            GameObject.DontDestroyOnLoad(this.gameObject);
        }
    }
}
