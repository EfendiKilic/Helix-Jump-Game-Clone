﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private GameObject Direct;
    private float RotateSpeed = 1f;
    private float MoveX;

    private Touch PlayerToch;

    private Vector3 TouchDown;
    private Vector3 TouchUp;
    private float x1;
    private float x2;
    private bool DragStarted;
    
    private void Awake()
    {
        Direct = GameObject.FindWithTag("Direct");
    }

    private void Update()
    {
        if (Input.touchCount > 0)
        { 
            PlayerToch = Input.GetTouch(0);

            if (PlayerToch.phase == TouchPhase.Began)
            { 
                TouchDown = PlayerToch.position;
                TouchUp = PlayerToch.position;
                x1 = TouchDown.x;
                x2 = TouchDown.x;
                DragStarted = true;
            }
        }
        if (DragStarted == true)
        {
            if (PlayerToch.phase == TouchPhase.Moved)
            {
                TouchDown = PlayerToch.position; 
                x2 = TouchDown.x;
            }

            if (PlayerToch.phase == TouchPhase.Ended)
            {
                DragStarted = false;
                TouchDown = PlayerToch.position;
                x2 = TouchDown.x;
            }
            
            Direct.transform.Rotate(0,((x2-x1) * RotateSpeed * Time.deltaTime) ,0f);
        }
        
    }
}
