﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Ball : MonoBehaviour
{
    private Rigidbody BallRb;
    private float JumpForce = 100f;

    [SerializeField] private GameObject Splash;
    [SerializeField] private AudioClip Effect;
    [SerializeField] private AudioSource GameAudioSouce;

    private void Awake()
    {
        BallRb = this.gameObject.GetComponent<Rigidbody>();
    }

    private void OnCollisionEnter(Collision collision)
    { 
        GameAudioSouce.PlayOneShot(Effect);
        
        BallRb.AddForce(Vector3.up * JumpForce);

        GameObject splash = Instantiate(Splash, transform.position - new Vector3(0, 0.22f, 0), transform.rotation);
        splash.transform.SetParent(collision.gameObject.transform);
        Destroy(splash, 2f);

        if (collision.gameObject.CompareTag("Barrier"))
        {
            SceneManager.LoadScene(2);
        }
        
        if (collision.gameObject.CompareTag("Finish"))
        {
            SceneManager.LoadScene(3);
        }
    }
}
