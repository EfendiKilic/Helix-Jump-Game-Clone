﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroyer : MonoBehaviour
{
    private Transform ball;
    [SerializeField] private AudioClip Effect;
    [SerializeField] private AudioSource GameAudioSouce;
    private void Awake()
    {
        ball = GameObject.FindWithTag("Ball").GetComponent<Transform>();
    }

    void Update()
    {
        if(transform.position.y - 3f >= ball.position.y)
        {
            GameAudioSouce.PlayOneShot(Effect);
            Destroy(gameObject);
        }    
    }
}
