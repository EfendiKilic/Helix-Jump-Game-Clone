﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Win : MonoBehaviour
{
    private Button RestartMatch;
    private Button BackMenu;


    private void Awake()
    {
        RestartMatch = GameObject.Find("RestartMatch").GetComponent<Button>();
        BackMenu = GameObject.Find("BackMenu").GetComponent<Button>();
    }

    private void Start()
    {
        BackMenu.onClick.AddListener(BacktoMenu);
        RestartMatch.onClick.AddListener(RestarttoMatch);
    }

    private void RestarttoMatch()
    {
        SceneManager.LoadScene(1);
    }

    private void BacktoMenu()
    {
        SceneManager.LoadScene(0);
    }
}
