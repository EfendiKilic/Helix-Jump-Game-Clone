﻿using System;
using System.Collections;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    private Button PlayButton;
    private Button QuitButton;

    private void Awake()
    {
        PlayButton = GameObject.Find("PlayButton").GetComponent<Button>();
        QuitButton = GameObject.Find("QuitButton").GetComponent<Button>();
    }

    private void Start()
    {
        QuitButton.onClick.AddListener(QuitGame);
        PlayButton.onClick.AddListener(PlayGame);
    }

    private void QuitGame()
    {
        Debug.Log("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        Application.Quit();
    }

    private void PlayGame()
    {
        SceneManager.LoadScene(1);
    }
}
